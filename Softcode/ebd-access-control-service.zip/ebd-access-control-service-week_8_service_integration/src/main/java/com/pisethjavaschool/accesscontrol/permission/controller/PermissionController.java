package com.pisethjavaschool.accesscontrol.permission.controller;

import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.pisethjavaschool.accesscontrol.permission.dto.CreatePermissionRequest;
import com.pisethjavaschool.accesscontrol.permission.dto.PermissionResponse;
import com.pisethjavaschool.accesscontrol.permission.dto.UpdatePermissionRequest;
import com.pisethjavaschool.accesscontrol.common.dto.UpdateStatusRequest;
import com.pisethjavaschool.accesscontrol.permission.facade.PermissionManagementFacade;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/access-control/permissions")
public class PermissionController {

    private final PermissionManagementFacade facade;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<PermissionResponse> create(@Valid @RequestBody CreatePermissionRequest request) {
        return facade.create(request);
    }

    @GetMapping
    public Flux<PermissionResponse> getAll() {
        return facade.getAll();
    }

    @GetMapping("/{permissionId}")
    public Mono<PermissionResponse> getById(@PathVariable UUID permissionId) {
        return facade.getById(permissionId);
    }

    @PutMapping("/{permissionId}")
    public Mono<PermissionResponse> update(@PathVariable UUID permissionId, @Valid @RequestBody UpdatePermissionRequest request) {
        return facade.update(permissionId, request);
    }

    @PatchMapping("/{permissionId}/status")
    public Mono<PermissionResponse> updateStatus(@PathVariable UUID permissionId, @Valid @RequestBody UpdateStatusRequest request) {
        return facade.updateStatus(permissionId, request);
    }

    @DeleteMapping("/{permissionId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Mono<Void> delete(@PathVariable UUID permissionId) {
        return facade.delete(permissionId);
    }
}
